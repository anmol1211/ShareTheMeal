package com.infoway.entites;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="donorfood")
public class Food {
	@Id
	private int fid;
	private String fqty;
	
	private int rid;
	
	public Food() {
		// TODO Auto-generated constructor stub
	}

	public Food(int fid, String fqty, int rid) {
		super();
		this.fid = fid;
		this.fqty = fqty;
		this.rid = rid;
	}

	@Override
	public String toString() {
		return "Food [fid=" + fid + ", fqty=" + fqty + ", rid=" + rid + "]";
	}
	
	

}
